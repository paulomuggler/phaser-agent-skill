# Phaser - HTML5 Game Framework Skill

## Overview

Phaser is a fast, free, and fun open source HTML5 game framework that offers WebGL and Canvas rendering across desktop and mobile web browsers. Use this skill when working with Phaser 3 game development, including:

- Building HTML5 games with JavaScript or TypeScript
- Game object management (sprites, images, text, graphics)
- Physics systems (Arcade Physics, Matter.js)
- Scene management and lifecycle
- Input handling (keyboard, mouse, touch, gamepad)
- Animation and tweens
- Audio management
- Camera systems and effects
- Asset loading and management

## Quick Start

### Installation

```bash
# Via npm
npm install phaser

# Using create-phaser-game app (recommended)
npm create @phaserjs/game@latest
```

### CDN Usage

```html
<script src="//cdn.jsdelivr.net/npm/phaser@3.88.2/dist/phaser.min.js"></script>
```

### Basic Game Template

```typescript
import Phaser from 'phaser';

const config: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

function preload(this: Phaser.Scene) {
    // Load assets
    this.load.image('sky', 'assets/sky.png');
    this.load.image('ground', 'assets/platform.png');
}

function create(this: Phaser.Scene) {
    // Create game objects
    this.add.image(400, 300, 'sky');
    const platforms = this.physics.add.staticGroup();
    platforms.create(400, 568, 'ground').setScale(2).refreshBody();
}

function update(this: Phaser.Scene) {
    // Game loop logic
}
```

## Core Concepts

### Scenes

Scenes are the building blocks of Phaser games. Each scene has its own lifecycle:

```typescript
class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    preload() {
        // Load assets
    }

    create() {
        // Initialize game objects
    }

    update(time: number, delta: number) {
        // Called every frame
    }
}

const config = {
    scene: [GameScene]
};
```

### Game Objects

Phaser provides many built-in game object types:

- **Sprites**: Animated images with physics bodies
- **Images**: Static images
- **Text**: Rendered text with styling
- **Graphics**: Vector graphics drawn via code
- **Containers**: Group multiple game objects
- **Tilemaps**: Efficient tile-based levels

```typescript
// Creating game objects
const sprite = this.add.sprite(100, 100, 'player');
const image = this.add.image(200, 200, 'logo');
const text = this.add.text(10, 10, 'Score: 0', { fontSize: '32px', color: '#fff' });
const graphics = this.add.graphics();
graphics.fillStyle(0xff0000, 1);
graphics.fillCircle(400, 300, 50);
```

### Physics

Phaser includes two physics engines:

**Arcade Physics** - Fast, simple AABB collision detection:

```typescript
// Enable physics on a sprite
const player = this.physics.add.sprite(100, 450, 'player');
player.setBounce(0.2);
player.setCollideWorldBounds(true);

// Collisions
this.physics.add.collider(player, platforms);
this.physics.add.overlap(player, stars, collectStar, null, this);
```

**Matter.js** - Advanced polygon collision and physics:

```typescript
this.matter.add.sprite(400, 0, 'box');
this.matter.add.mouseSpring();
```

### Input Handling

```typescript
// Keyboard
const cursors = this.input.keyboard.createCursorKeys();
if (cursors.left.isDown) {
    player.setVelocityX(-160);
}

// Mouse/Touch
this.input.on('pointerdown', (pointer) => {
    console.log(pointer.x, pointer.y);
});

// Gamepad
const pad = this.input.gamepad.getPad(0);
```

### Animation

```typescript
// Create animation
this.anims.create({
    key: 'run',
    frames: this.anims.generateFrameNumbers('player', { start: 0, end: 7 }),
    frameRate: 10,
    repeat: -1
});

// Play animation
player.anims.play('run');

// Tweens for smooth transitions
this.tweens.add({
    targets: sprite,
    x: 400,
    duration: 2000,
    ease: 'Power2'
});
```

### Audio

```typescript
// Load sound
this.load.audio('music', 'assets/music.mp3');

// Play sound
const music = this.sound.add('music');
music.play();

// Sound effects
this.sound.play('jump');
```

### Cameras

```typescript
// Follow player
this.cameras.main.startFollow(player);

// Camera effects
this.cameras.main.shake(500);
this.cameras.main.flash(250);
this.cameras.main.fade(1000);

// Set bounds
this.cameras.main.setBounds(0, 0, 1920, 1080);
```

## TypeScript Support

Phaser 3 includes full TypeScript definitions:

```json
{
  "compilerOptions": {
    "lib": ["es6", "dom", "dom.iterable", "scripthost"],
    "typeRoots": ["./node_modules/phaser/types"],
    "types": ["Phaser"]
  }
}
```

### Type-Safe Configuration

```typescript
const config: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container',
    backgroundColor: '#2d2d2d',
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },
    scene: [PreloadScene, MenuScene, GameScene]
};
```

## Framework Integration

Phaser works with 40+ frameworks:

- **React**: Use `useEffect` to initialize game
- **Vue**: Initialize in `mounted()` hook
- **Angular**: Initialize in `ngAfterViewInit()`
- **Next.js**: Dynamic import with `ssr: false`
- **SolidJS, Svelte, Remix**: Official templates available

## Common Patterns

### Scene Management

```typescript
// Switch scenes
this.scene.start('GameScene');
this.scene.pause('GameScene');
this.scene.resume('GameScene');
this.scene.stop('GameScene');

// Run multiple scenes
this.scene.launch('UIScene');

// Pass data between scenes
this.scene.start('NextLevel', { score: 1000, level: 2 });
```

### Object Pooling

```typescript
const bullets = this.physics.add.group({
    classType: Bullet,
    maxSize: 30,
    runChildUpdate: true
});

// Get/recycle objects
const bullet = bullets.get(x, y);
```

### State Management

```typescript
class GameScene extends Phaser.Scene {
    private score: number = 0;
    private scoreText: Phaser.GameObjects.Text;

    updateScore(points: number) {
        this.score += points;
        this.scoreText.setText(`Score: ${this.score}`);
    }
}
```

## Performance Tips

1. **Use object pools** for frequently created/destroyed objects
2. **Limit physics bodies** - only add physics to objects that need it
3. **Use texture atlases** instead of individual images
4. **Optimize collision detection** with groups and collision categories
5. **Disable unused systems** in game config
6. **Use camera culling** for large scenes
7. **Profile with** `this.game.config.fps` and Chrome DevTools

## Resources

- **API Documentation**: https://docs.phaser.io/
- **Examples**: https://labs.phaser.io (2000+ examples)
- **Tutorials**: https://phaser.io/learn (700+ tutorials)
- **Discord Community**: https://discord.gg/phaser
- **GitHub**: https://github.com/phaserjs/phaser

## Version Information

This skill is based on Phaser 3.88.2 (latest stable release). Phaser has been actively developed for over 10 years and is one of the most starred JavaScript game frameworks on GitHub (38,000+ stars).

## Quick Reference

### Most Common APIs

- `this.add.*` - Create game objects
- `this.physics.add.*` - Physics-enabled objects
- `this.load.*` - Asset loading
- `this.input.*` - Input handling
- `this.anims.*` - Animation management
- `this.sound.*` - Audio management
- `this.cameras.main.*` - Camera controls
- `this.scene.*` - Scene management
- `this.time.*` - Timers and delays
- `this.tweens.*` - Smooth animations

### Event System

```typescript
// Custom events
this.events.on('gameOver', this.handleGameOver, this);
this.events.emit('gameOver', { score: 1000 });

// Scene events
this.events.on('create', () => {});
this.events.on('update', () => {});
```

This skill provides comprehensive support for Phaser 3 game development. For specific API details, refer to the official documentation at https://docs.phaser.io/.
