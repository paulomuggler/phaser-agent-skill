# Getting Started with Phaser 3

## Installation

### Via NPM
```bash
npm install phaser
```

### Via CDN
```html
<script src="//cdn.jsdelivr.net/npm/phaser@3.88.2/dist/phaser.min.js"></script>
```

### Using Create Phaser Game App
The easiest way to start:
```bash
npm create @phaserjs/game@latest
```

This CLI tool provides templates for:
- Vue.js, React, Angular, Next.js, SolidJS, Svelte, Remix
- Bundlers: Vite, Rollup, Parcel, Webpack, ESBuild, Bun
- Both JavaScript and TypeScript versions

## Your First Game

### Basic HTML Setup
```html
<!DOCTYPE html>
<html>
<head>
    <script src="//cdn.jsdelivr.net/npm/phaser@3.88.2/dist/phaser.min.js"></script>
</head>
<body>
    <script>
        const config = {
            type: Phaser.AUTO,
            width: 800,
            height: 600,
            scene: {
                preload: preload,
                create: create
            }
        };

        const game = new Phaser.Game(config);

        function preload() {
            // Load assets
        }

        function create() {
            this.add.text(400, 300, 'Hello Phaser!', {
                fontSize: '32px',
                color: '#fff'
            }).setOrigin(0.5);
        }
    </script>
</body>
</html>
```

### TypeScript Project Setup

1. Install dependencies:
```bash
npm install phaser
npm install --save-dev typescript @types/node
```

2. Create `tsconfig.json`:
```json
{
  "compilerOptions": {
    "target": "ES2015",
    "module": "ES2015",
    "lib": ["es6", "dom", "dom.iterable", "scripthost"],
    "typeRoots": ["./node_modules/phaser/types"],
    "types": ["Phaser"],
    "moduleResolution": "node",
    "strict": true
  }
}
```

3. Create your game:
```typescript
import Phaser from 'phaser';

class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    preload() {
        // Load assets
    }

    create() {
        this.add.text(400, 300, 'Hello TypeScript!', {
            fontSize: '32px',
            color: '#fff'
        }).setOrigin(0.5);
    }
}

const config: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: [GameScene]
};

const game = new Phaser.Game(config);
```

## Game Configuration

The game config object controls your game's behavior:

```typescript
const config: Phaser.Types.Core.GameConfig = {
    // Rendering
    type: Phaser.AUTO,              // AUTO, WEBGL, or CANVAS
    width: 800,
    height: 600,
    parent: 'game-container',       // DOM element ID
    backgroundColor: '#2d2d2d',

    // Physics
    physics: {
        default: 'arcade',           // 'arcade' or 'matter'
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    },

    // Scenes
    scene: [PreloadScene, GameScene],

    // Scale
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },

    // Audio
    audio: {
        disableWebAudio: false
    },

    // Rendering options
    render: {
        antialias: true,
        pixelArt: false,
        roundPixels: false
    }
};
```

## Next Steps

1. **Learn Scene Lifecycle**: Understand `preload`, `create`, and `update`
2. **Add Game Objects**: Sprites, images, text, graphics
3. **Implement Physics**: Collisions and movement
4. **Handle Input**: Keyboard, mouse, touch
5. **Add Animation**: Sprite sheets and tweens
6. **Load Assets**: Images, audio, sprite sheets
7. **Create UI**: Score displays, health bars, buttons

## Learning Resources

- **Official Tutorials**: https://phaser.io/learn
- **API Documentation**: https://docs.phaser.io/
- **Examples**: https://labs.phaser.io (2000+ examples)
- **Community Discord**: https://discord.gg/phaser
- **Making Your First Game**: https://phaser.io/tutorials/making-your-first-phaser-3-game
